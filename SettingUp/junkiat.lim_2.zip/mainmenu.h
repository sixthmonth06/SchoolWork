#pragma once

void Main_Menu_Init(void);
void Main_Menu_Update(void);
void Main_Menu_Exit(void);
void Setting_Font(void);
void Play_Button(void);
void Exit_Button(void);
